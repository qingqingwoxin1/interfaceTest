"""
这个文件主要来通过get、post、put、delete等方法进行http请求，并拿到请求响应
"""
import requests
# import json
from testFile.readConfig import ReadConfig
from common.log import Logger

log=Logger().get_logger()
readconfig=ReadConfig()
timeout=readconfig.get_http("timeout")
headers={'magic':readconfig.get_magic('magic')}
class RunMain():

    def send_post(self, url, data,files):  # 定义一个方法，传入需要的参数url和data
        # 参数必须按照url、data顺序传入
        try:
            res = requests.post(url=url,headers=headers,data=data,files=files,timeout=float(timeout))# 因为这里要封装post方法，所以这里的url和data值不能写死
            # print(res)
            # res = json.dumps(res, ensure_ascii=False, sort_keys=True,separators=(',',':'))
            return res
        except Exception as  e:
            log.error(e)
            return  None

    def send_get(self, url, data):
        try:
            res = requests.get(url=url,headers=headers,params=data,timeout=float(timeout))
            # res = json.dumps(res, ensure_ascii=False, sort_keys=True, indent=2)
            return res
        except Exception as e:
            log.error(e)
            return  None
    def run_main(self, method, url=None, data=None,files=None):  # 定义一个run_main函数，通过传过来的method来进行不同的get或post请求
        res = None
        if method == 'post':
            res = self.send_post(url, data,files)
        elif method == 'get':
            res = self.send_get(url, data)
        else:
            print("method值错误！！！")
        return res


if __name__ == '__main__':  # 通过写死参数，来验证我们写的请求是否正确
    # data={"project_name":"66","project_number":"88888888886666666B66","group_number":"88888888886666666B","difficulty_degree":5,"file_name":"44CORD20197359TELB.txt","platform_number":11,"task_number_pre":4,"project_length_time":1248.785}
    # result1 = RunMain().run_main('post', 'http://dev.crowd.imagicdatatech.com/api/public/ucenter/project',data=data)
    # result2 = RunMain().run_main('get', 'http://127.0.0.1:8888/login', 'username=liuguiju&password=123456')
    data={"p_id":1423}
    res=RunMain().run_main('post','http://dev.crowd.imagicdatatech.com/api/two/project/getprojectconf',data=data)
    # print(res)
    # print(result2)
