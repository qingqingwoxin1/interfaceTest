import pymysql
from testFile.readConfig import ReadConfig

host=ReadConfig().get_mysql('host')
port=ReadConfig().get_mysql('port')
user=ReadConfig().get_mysql('username')
passwd=ReadConfig().get_mysql('password')
db=ReadConfig().get_mysql('database')
charset=ReadConfig().get_mysql('charset')

class DB:
    def __init__(self):
        # 建立数据库连接，设置 autocommit=True 自动提交事务
        self.conn = pymysql.connect(host=host,
                                    port=int(port),
                                    user=user,
                                    passwd=passwd,
                                    db=db,
                                    charset=charset,autocommit=True)
        # 创建游标
        self.cur = self.conn.cursor()

    def __del__(self):  # 析构函数，实例删除时触发
         # 关闭游标
         self.cur.close()
         # 关闭数据库连接
         self.conn.close()

    def query(self, table_name, field_name, value):
        #检查连接是否断开，如果断开就进行重连
        self.conn.ping(reconnect=True)
        # value需加单引号，否则报错
        sql = "select * from {} where {} = '{}'".format(table_name, field_name, value)
        #使用execute执行sql
        self.cur.execute(sql)
        # 使用fetchall获取查询结果
        result = self.cur.fetchall()
        # self.conn.commit()
        return result


    def exec(self, sql):
        try:
            # 检查连接是否断开，如果断开就进行重连
            self.conn.ping(reconnect=True)
            self.cur.execute(sql)
            # 提交事务
            self.conn.commit()
        except Exception as e:
            # 回滚所有更改
            self.conn.rollback()
            print(str(e))
    def check_user(self,table_name,field_name, value):
        res= self.query(table_name,field_name,value)
        return True if res else False

    def del_user(self,table_name, field_name,value):
        self.exec("delete from {} where {}='{}'".format(table_name,field_name,value))

if __name__ == '__main__':
    project_number = '88888888886666666B66'
    db = DB()  # 实例化一个数据库操作对象
    # res=db.check_user('uc_project','project_number','77777777777777777B88')
    res=db.query('uc_project','project_number','77777777777777777B88')
    print(res)
    # res=db.query('uc_project','project_number','88888888886666666B66')
    # res=db.check_user('uc_project','project_number',project_number)
    # print(res)
    # if res:
    #     print('返回成功')
    import os
    # sql_url='../testFile/sql/uc_project'
    # f=open(sql_url,'r')
    # sql=f.read()
    # db.exec(sql)

