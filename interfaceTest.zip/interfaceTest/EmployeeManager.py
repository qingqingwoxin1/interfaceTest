"""
封装-员工管理器类、测试类、开发类，分而治之思想
继承-抽象出父类员工类，员工管理器调员工类，不调字，隔离变化
多态-子类重写父类方法，在基础上进行扩展
开闭原则-原功能不可变,新可能可加
单一原则-各行其是,低耦合
依赖原则-调父不调子
迪米特原则-客户端调父不调子,子类与子类之间低耦合
组合复用-传父创建子类对象作为参数,达到复用目的
里氏替换-
"""
# 架构师
class EmployeeManager:
    def __init__(self):
        self.all_list=[]
    def add_employee(self, emp):
        # 调父不调子
        self.all_list.append(emp)
    def get_total_money(self):
        total_money=0
        for emp in self.all_list:
            total_money+=emp.calculate()
        return total_money
class Employee:
    def calculate(self):
        return 100
# 程序员
class Tester(Employee):
    def calculate(self):
        return 10000
class Programmer(Employee):
    def calculate(self):
        return 20000
e1=EmployeeManager()
E1=Employee()
# t1=Tester()
p1=Programmer()
# e1.add_employee(E1)
e1.add_employee(p1)
# print(e1.get_total_money())

#
#
# el7 = driver.find_element_by_id("com.magicdata:id/login_edname")
# el7.send_keys("15811411759")
# el8 = driver.find_element_by_id("com.magicdata:id/login_edpass")
# el8.send_keys("a1111111")
# el9 = driver.find_element_by_id("com.magicdata:id/login_btnlogin")
# el9.click()
from appium import webdriver
desired_caps = {}
desired_caps['platformName'] = 'Android' # 设备系统
desired_caps['platformVersion'] = '10' # 设备系统版本
desired_caps['deviceName'] = 'SEA_AL00' # 设备名称
desired_caps['appPackage'] = 'com.magicdata'
desired_caps['appActivity'] = 'com.magicdata.activity.login.WelcomeActivity'
desired_caps['automationName']='uiautomator2'
driver = webdriver.Remote("http://localhost:4723/wd/hub", desired_caps)
el1 = driver.find_element_by_id("com.android.permissioncontroller:id/permission_allow_button")
el1.click()
el1.click()
el2 = driver.find_element_by_xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.support.v4.view.ViewPager/android.view.ViewGroup")
el2.click()
el2.click()
el3 = driver.find_element_by_xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.support.v4.view.ViewPager/android.view.ViewGroup")
el3.click()
el4 = driver.find_element_by_id("com.magicdata:id/jump_btn")
el4.click()
el5 = driver.find_element_by_xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.RelativeLayout[3]/android.widget.LinearLayout/android.widget.ImageView")
el5.click()
el6 = driver.find_element_by_id("com.magicdata:id/login_tv")
el6.click()
el7 = driver.find_element_by_id("com.magicdata:id/login_edname")
el7.send_keys("13100000011")
el8 = driver.find_element_by_id("com.magicdata:id/login_edpass")
el8.send_keys("123456789")
el9 = driver.find_element_by_id("com.magicdata:id/login_btnlogin")
el9.click()
