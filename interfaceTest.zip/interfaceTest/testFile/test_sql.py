"""
测试数据库连接池的文件
"""
import pymysql
class DB:
    def __init__(self):
        self.db=pymysql.connect(
            host='127.0.0.1',
            port=3306,
            user='root',
            password='a1111111',
            database='student',
            charset='utf8'
            )
        self.cursor=self.db.cursor()
    def query(self,name):
        sql='select * from user where user= "{}"'.format(name)
        self.cursor.execute(sql)
        return self.cursor.fetchall()
    def exec(self,r_list):
        sql = "insert into user (user,password) values(%s,%s)"
        try:
            self.cursor.executemany(sql,r_list)
            self.db.commit()
        except Exception as e:
            print(e)
            self.db.rollback()
    def __del__(self):
        self.cursor.close()
        self.db.close()
if __name__ == '__main__':
    db=DB()
    r_list=[('liuguiju','222222'),('liuguiju','111111')]
    db.exec(r_list)
    # db.exec('delete from user where user="liuguiju"')
    # re=db.query('liuguiju')
    # print(re)


