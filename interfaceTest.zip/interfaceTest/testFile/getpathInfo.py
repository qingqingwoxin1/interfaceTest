"""
获取项目绝对路径
"""

import os


# 获取getpathInfo文件的绝对路径
def get_path(file):
    path = os.path.split(os.path.realpath(file))[0]
    return path

if __name__ == '__main__':  # 执行该文件，测试下是否OK
    print('测试路径是否OK,路径为：', get_path('sql/uc_project'))
    # print(os.path.realpath(__file__))
