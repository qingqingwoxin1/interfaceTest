"""
读取userCase.xlsx中的用例，使用unittest来进行断言校验
"""
import json
import unittest
from common.configHttp import RunMain
import paramunittest
from testFile.geturlParams import geturlParams
from testFile.readExcel import readExcel
from testFile.readConfig import ReadConfig
readconfig=ReadConfig()
url = geturlParams().get_Url(readconfig.get_http('baseurl_second'),'api/public/ucenter/project')  # 调用我们的geturlParams获取我们拼接的URL
project_xls = readExcel().get_xls('userCase.xlsx', 'filecheck')

@paramunittest.parametrized(*project_xls)
class testProjectAdd(unittest.TestCase):
    def setParameters(self,case_no,case_name,path,method,expect_code,expect_content):
        """
        :param case_no:
        :param case_name:
        :param path:
        :param method:
        :param expect_code:
        :param expect_content:
        :return:
        """
        self.no=str(case_no)
        self.case_name = str(case_name)
        self.path = str(path)
        self.method = str(method)
        self.expect_code=int(expect_code)
        self.expect_content=expect_content

    def description(self):
        """
        test report description
        :return:
        """
        self.case_name

    def setUp(self):
        """
        :return:
        """
        print(self.case_name + "测试开始前准备")
    def tearDown(self):
        print("测试结束，输出log完结\n\n")
    def test_project_case(self):
        self.checkResult()
    def checkResult(self):  # 断言
        if self.case_name == 'filecheck_success':
            url = geturlParams().get_Url(readconfig.get_http('baseurl_second'),
                                        self.path)  # 调用我们的geturlParams获取我们拼接的URL
            upload_file_url='../testFile/uploadfile/19CORD20197359TELB.txt'
            file_name='79CORD20197359TELB.txt'
            f=open(upload_file_url,'r')
            body={
                'file_name':(file_name,f,'text/plain')
            }
            info = RunMain().run_main(self.method, url,files=body)  # 根据Excel中的method调用run_main来进行requests请求，并拿到响应
            ss = info.json() # 将响应转换为字典格式
            f.close()
            self.assertEqual(self.expect_code,ss['code'])
if __name__ == '__main__':
    unittest.main(verbosity=2)

