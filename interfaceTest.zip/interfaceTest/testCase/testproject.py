"""
读取userCase.xlsx中的用例，使用unittest来进行断言校验
"""
import json
import unittest
from common.configHttp import RunMain
import paramunittest
from testFile.geturlParams import geturlParams
from testFile.readExcel import readExcel
from common.configDB import DB
from testFile.readConfig import ReadConfig
from testFile.getpathInfo import get_path
import os
import  random
readconfig=ReadConfig()
url = geturlParams().get_Url(readconfig.get_http('baseurl_second'),'api/public/ucenter/project')  # 调用我们的geturlParams获取我们拼接的URL
integer=random.randint(10000000,99999999)
file_name = '19CORD{}TELB.txt'.format(integer)
project_xls = readExcel().get_xls('userCase.xlsx', 'project')
# sql文件路径
sql_url=os.path.join(get_path('../testFile/sql/uc_project'), 'uc_project')
db=DB()

@paramunittest.parametrized(*project_xls)
class testProjectAdd(unittest.TestCase):
    def setParameters(self,case_no,case_name, path,headers,data,method,expect_code,expect_content):
        """
        :param case_no:
        :param case_name:
        :param path:
        :param headers:
        :param data:
        :param method:
        :param expect_code:
        :param expect_content:
        :return:
        """
        self.no=str(case_no)
        self.case_name = str(case_name)
        self.path = str(path)
        self.headers=str(headers)
        self.data=str(data)
        self.method = str(method)
        self.expect_code=int(expect_code)
        self.expect_content=expect_content

    def description(self):
        """
        test report description
        :return:
        """
        self.case_name

    def setUp(self):
        """
        :return:
        """
        print(self.case_name + "测试开始前准备")
        # 数据检查，新增接口，检查project_number是否存在，存在则删除
        if db.check_user('uc_project', 'project_number', readconfig.get_project_number('project_number')):
            db.del_user('uc_project', 'project_number', readconfig.get_project_number('project_number'))
    def tearDown(self):
        #数据清理，case执行完后还原数据
        db.del_user('uc_project', 'project_number', readconfig.get_project_number('project_number'))
        print("测试结束，输出log完结\n\n")
    def test_project_case(self):
        self.checkResult()
    def get_filecheck_info(self):
        """
        获取filecheck响应,取得值传给project接口
        :return:
        """
        url = geturlParams().get_Url(readconfig.get_http('baseurl_second'),
                                     'crowdgin/userCenter/fileCheck')  # 调用我们的geturlParams获取我们拼接的URL
        upload_file_url = '../testFile/uploadfile/19CORD20197359TELB.txt'
        f = open(upload_file_url, 'r')
        body = {
            'file_name': (file_name, f, 'text/plain')
        }
        info = RunMain().run_main(self.method, url, files=body)  # 根据Excel中的method调用run_main来进行requests请求，并拿到响应
        ss = info.json()  # 将响应转换为字典格式
        f.close()
        return ss['data']
    def checkResult(self):  # 断言
        """
        :return:
        """

        data =json.loads(self.data,encoding='utf8')
        if self.case_name == 'project_success':
            # 获取filecheck响应,Qualified_Total_Package、Qualified_Total_Time值传给project中的task_number_pre、project_length_time
            res=self.get_filecheck_info()
            # import time
            # time.sleep(30)
            data['file_name']=file_name
            data['task_number_pre']=res['Qualified_Total_Package']
            data['project_length_time']=res['Qualified_Total_Time']
            info = RunMain().run_main(self.method, url, data)  # 根据Excel中的method调用run_main来进行requests请求，并拿到响应
            ss = info.json()  # 将响应转换为字典格式
            # 整体断言，验证是否新增成功
            self.assertEqual(self.expect_code,ss['code'])
            #数据库断言，验证是否新增成功
            self.assertTrue(db.check_user('uc_project', 'project_number', data['project_number']))
        #验证project_number重复后端响应效果
        if self.case_name == 'project_exist':
            with open(sql_url,'r',encoding='utf-8') as f:
                sql=f.read()
                db.exec(sql)
            info = RunMain().run_main(self.method, url, data)  # 根据Excel中的method调用run_main来进行requests请求，并拿到响应
            ss = info.json()  # 将响应转换为字典格式
            self.assertEqual(self.expect_code,ss['code'])
if __name__ == '__main__':
    unittest.main(verbosity=2)

