"""
读取userCase.xlsx中的用例，使用unittest来进行断言校验
"""
import json
import unittest
from common.configHttp import RunMain
import paramunittest
import urllib.parse
from testFile.geturlParams import geturlParams
from testFile.readExcel import readExcel
from testFile.readConfig import ReadConfig
readconfig=ReadConfig()
url = geturlParams().get_Url(readconfig.get_http('baseurl_first'),'user/login/accountLogin')  # 调用我们的geturlParams获取我们拼接的URL
login_xls = readExcel().get_xls('userCase.xlsx', 'login')
@paramunittest.parametrized(*login_xls)
class testUserLogin(unittest.TestCase):
    def setParameters(self,case_no,case_name, path,query, method,expect_result,expect_content):
        """
        set params
        :param case_name:
        :param path
        :param query
        :param method
        :return:
        """
        self.no=str(case_no)
        self.case_name = str(case_name)
        self.path = str(path)
        self.query = str(query)
        self.method = str(method)
        self.expect_result=int(expect_result)
        self.expect_content=expect_content

    def description(self):
        """
        test report description
        :return:
        """
        self.case_name

    def setUp(self):
        """
        :return:
        """
        print(self.case_name + "测试开始前准备")

    def tearDown(self) :
        print("测试结束，输出log完结")
    def test_login_case(self):
        self.checkResult()

    def checkResult(self):  # 断言
        """
        check test result
        :return:
        """
        # url1 = url
        new_url = url + self.query
        data1 = dict(urllib.parse.parse_qsl(
            urllib.parse.urlsplit(new_url).query))  # 将一个完整的URL中的name=&password=转换为{'username':'xxx','password':'bbb'}
        info = RunMain().run_main(self.method, url, data1)  # 根据Excel中的method调用run_main来进行requests请求，并拿到响应
        ss = info.json()  # 将响应转换为字典格式
        if self.case_name == 'login':  # 如果case_name是login，说明合法，返回的code应该为200
            self.assertEqual(self.expect_result,ss['code'])
        if self.case_name == 'login_error':  # 同上
            self.assertEqual(self.expect_result,ss['code'])
        if self.case_name == 'login_null':  # 同上
            self.assertEqual(self.expect_result,ss['code'])
if __name__ == '__main__':
    unittest.main(verbosity=2)

