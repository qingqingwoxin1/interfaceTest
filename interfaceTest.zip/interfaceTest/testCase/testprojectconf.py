"""
读取userCase.xlsx中的用例，使用unittest来进行断言校验
"""
import json
import unittest
from common.configHttp import RunMain
import paramunittest
from testFile.geturlParams import geturlParams
from testFile.readExcel import readExcel
from common.configDB import DB
from testFile.readConfig import ReadConfig
readconfig=ReadConfig()
project_xls = readExcel().get_xls('userCase.xlsx', 'getprojectconf')
db=DB()
sql_url='../testFile/sql/uc_project'
# 数据准备


@paramunittest.parametrized(*project_xls)
class testProjectConf(unittest.TestCase):
    def setParameters(self,case_no,case_name,path,data,method,expect_code,expect_content):
        """

        :param case_no:
        :param case_name:
        :param path:
        :param headers:
        :param data:
        :param method:
        :param expect_code:
        :param expect_content:
        :return:
        """
        self.no=str(case_no)
        self.case_name = str(case_name)
        self.path = str(path)
        self.data=str(data)
        self.method = str(method)
        self.expect_code=int(expect_code)
        self.expect_content=expect_content

    def description(self):
        """
        test report description
        :return:
        """
        self.case_name

    def setUp(self):
        """
        :return:
        """
        print(self.case_name + "测试开始前准备")
        # 数据检查，依赖testproject接口，若没有数据，进行插入
        if not db.check_user('uc_project', 'project_number',  readconfig.get_project_number('project_number')):
            with open(sql_url,'r') as f:
                db.exec(f.read())

    def tearDown(self):
        # 数据清理，需清空数据
        db.del_user('uc_project', 'project_number', readconfig.get_project_number('project_number'))
        print("测试结束，输出log完结\n\n")
    def test_project_conf_case(self):
        self.checkResult()

    def checkResult(self):  # 断言
        """
        :return:
        """
        url = geturlParams().get_Url(readconfig.get_http('baseurl_second'),
                                     self.path)  # 调用我们的geturlParams获取我们拼接的URL
        data =json.loads(self.data,encoding='utf8')
        # p_id为动态获取，为新增表uc_project mid的值
        mid = db.query('uc_project', 'project_number', readconfig.get_project_number('project_number'))[0][0]
        data['p_id'] = mid
        info = RunMain().run_main(self.method, url, data)  # 根据Excel中的method调用run_main来进行requests请求，并拿到响应
        # print(info)
        ss = info.json()  # 将响应转换为字典格式
        # print(ss)
        if self.case_name == 'getprojectconf_success':  # 如果case_name是login，说明合法，返回的code应该为200
            # 整体断言，验证是否新增成功
            self.assertEqual(self.expect_code,ss['code'])

if __name__ == '__main__':
    unittest.main(verbosity=2)

