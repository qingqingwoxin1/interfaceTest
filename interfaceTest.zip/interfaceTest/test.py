# # # # # # # """asdsdddddddddddddddddddddd"""
# # # # # # # # # # import logging
# # # # # # # # # #
# # # # # # # # # # logger = logging.getLogger(__name__)
# # # # # # # # # # logger.setLevel(level=logging.INFO)
# # # # # # # # # # handler = logging.FileHandler("log.txt")
# # # # # # # # # # handler.setLevel(logging.INFO)
# # # # # # # # # # formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# # # # # # # # # # handler.setFormatter(formatter)
# # # # # # # # # #
# # # # # # # # # # console = logging.StreamHandler()
# # # # # # # # # # console.setLevel(logging.INFO)
# # # # # # # # # #
# # # # # # # # # # logger.addHandler(handler)
# # # # # # # # # # logger.addHandler(console)
# # # # # # # # # #
# # # # # # # # # # logger.info("Start print log")
# # # # # # # # # # logger.debug("Do something")
# # # # # # # # # # logger.warning("Something maybe fail.")
# # # # # # # # # # logger.info("Finish")
# # # # # # # # #
# # # # # # # # # # list=[1,3,4]
# # # # # # # # # # str="hello world"
# # # # # # # # # # for i in str:
# # # # # # # # # #     print(i)
# # # # # # # # #
# # # # # # # # # import unittest
# # # # # # # # # import os
# # # # # # # # #
# # # # # # # # # import TestUserLogin
# # # # # # # # # from common import HTMLTestRunner
# # # # # # # # #
# # # # # # # # # suite=unittest.TestSuite()
# # # # # # # # # suite.addTest(TestUserLogin.TestUserLogin("test_login_success"))
# # # # # # # # # # unittest.TextTestRunner().run(suite)
# # # # # # # # # # os.mknod("report.html")
# # # # # # # # # fp=open("./report.html","wb")
# # # # # # # # # runner=HTMLTestRunner.HTMLTestRunner(stream=fp,title="接口测试报告",description="测试描述")
# # # # # # # # # runner.run(suite)
# # # # # # # # # fp.close()
# # # # # # # # # import logging  # 引入logging模块
# # # # # # # # # # 将信息打印到控制台上
# # # # # # # # # logging.debug(u"苍井空")
# # # # # # # # # logging.info(u"麻生希")
# # # # # # # # # logging.warning(u"小泽玛利亚")
# # # # # # # # # logging.error(u"桃谷绘里香")
# # # # # # # # # logging.critical(u"泷泽萝拉")
# # # # # # # # # import logging  # 引入logging模块
# # # # # # # # # # logging.basicConfig(level=logging.NOTSET)  # 设置日志级别
# # # # # # # # # # logging.debug(u"如果设置了日志级别为NOTSET,那么这里可以采取debug、info的级别的内容也可以显示在控制台上了")
# # # # # # # # # # logging.info(u"如果设置了日志级别为NOTSET,那么这里可以采取debug、info的级别的内容也可以显示在控制台上了")
# # # # # # # # # import logging  # 引入logging模块
# # # # # # # # # logging.basicConfig(level=logging.DEBUG,
# # # # # # # # #                     format='%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s')  # logging.basicConfig函数对日志的输出格式及方式做相关配置
# # # # # # # # # # 由于日志基本配置中级别设置为DEBUG，所以一下打印信息将会全部显示在控制台上
# # # # # # # # # logging.info('this is a loggging info message')
# # # # # # # # # logging.debug('this is a loggging debug message')
# # # # # # # # # logging.warning('this is loggging a warning message')
# # # # # # # # # logging.error('this is an loggging error message')
# # # # # # # # # logging.critical('this is a loggging critical message')
# # # # # # # # # import logging  # 引入logging模块
# # # # # # # # # import os.path
# # # # # # # # # import time
# # # # # # # # # # 第一步，创建一个logger
# # # # # # # # # logger = logging.getLogger()
# # # # # # # # # logger.setLevel(logging.INFO)  # Log等级总开关
# # # # # # # # # # 第二步，创建一个handler，用于写入日志文件
# # # # # # # # # rq = time.strftime('%Y%m%d%H%M', time.localtime(time.time()))
# # # # # # # # # # logger.warning(rq)
# # # # # # # # # # log_path = os.path.dirname(os.getcwd()) + '/Logs/'
# # # # # # # # # log_path="./LOGS/"
# # # # # # # # # if not os.path.exists(log_path):
# # # # # # # # #     os.makedirs(log_path)
# # # # # # # # # # logger.warning(log_path)
# # # # # # # # # log_name = log_path + rq + '.log'
# # # # # # # # # # print(log_name)
# # # # # # # # # logfile = log_name
# # # # # # # # # fh = logging.FileHandler(logfile, mode='w')
# # # # # # # # # # print(fh)
# # # # # # # # # fh.setLevel(logging.WARNING)  # 输出到file的log等级的开关
# # # # # # # # # # # 第三步，定义handler的输出格式
# # # # # # # # # formatter = logging.Formatter("%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s")
# # # # # # # # # # print(formatter)
# # # # # # # # # fh.setFormatter(formatter)
# # # # # # # # # # # 第四步，将logger添加到handler里面
# # # # # # # # # logger.addHandler(fh)
# # # # # # # # # # 日志
# # # # # # # # # logger.debug('this is a logger debug message')
# # # # # # # # # logger.info('this is a logger info message')
# # # # # # # # # logger.warning('this is a logger warning message')
# # # # # # # # # logger.error('this is a logger error message')
# # # # # # # # # logger.critical('this is a logger critical message')
# # # # # # # #
# # # # # # # #
# # # # # # # # # import os.path
# # # # # # # # # import time
# # # # # # # # # import logging
# # # # # # # # # # 创建一个logger
# # # # # # # # # logger = logging.getLogger()
# # # # # # # # # logger.setLevel(logging.INFO)  # Log等级总开关
# # # # # # # # #
# # # # # # # # # # 创建一个handler，用于写入日志文件
# # # # # # # # # rq = time.strftime('%Y%m%d%H%M', time.localtime(time.time()))
# # # # # # # # # # log_path = os.path.dirname(os.getcwd()) + '/Logs/'
# # # # # # # # # log_path="./LOGS/"
# # # # # # # # # if not os.path.exists(log_path):
# # # # # # # # #     os.makedirs(log_path)
# # # # # # # # # log_name = log_path + rq + '.log'
# # # # # # # # # logfile = log_name
# # # # # # # # # fh = logging.FileHandler(logfile, mode='w')
# # # # # # # # # fh.setLevel(logging.DEBUG)  # 输出到file的log等级的开关
# # # # # # # # # ch = logging.StreamHandler()
# # # # # # # # # ch.setLevel(logging.WARNING)  # 输出到console的log等级的开关
# # # # # # # # #
# # # # # # # # # # 定义handler的输出格式
# # # # # # # # # formatter = logging.Formatter("%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s")
# # # # # # # # # fh.setFormatter(formatter)
# # # # # # # # # logger.addHandler(fh)
# # # # # # # # # ch.setFormatter(formatter)
# # # # # # # # # logger.addHandler(ch)
# # # # # # # # # # 使用logger.XX来记录错误,这里的"error"可以根据所需要的级别进行修改
# # # # # # # # # try:
# # # # # # # # #     open('/path/to/does/not/exist', 'rb')
# # # # # # # # # except Exception as e:
# # # # # # # # #     logger.error('Failed to open file', exc_info=False)
# # # # # # # #
# # # # # # # # # import logging
# # # # # # # # #
# # # # # # # # #
# # # # # # # # # def write_warning():
# # # # # # # # #     logging.warning(u"记录文件warning_output.py的日志")
# # # # # # # # # write_warning()
# # # # # # # #
# # # # # # # # import logging
# # # # # # # # import time
# # # # # # # # import re
# # # # # # # # from logging.handlers import TimedRotatingFileHandler
# # # # # # # # from logging.handlers import RotatingFileHandler
# # # # # # # #
# # # # # # # # # from xlrd import open_workbook
# # # # # # # #
# # # # # # # #
# # # # # # # # def backroll():
# # # # # # # #     #日志打印格式
# # # # # # # #     log_fmt = '%(asctime)s\tFile \"%(filename)s\",line %(lineno)s\t%(levelname)s: %(message)s'
# # # # # # # #     formatter = logging.Formatter(log_fmt)
# # # # # # # #     #创建TimedRotatingFileHandler对象
# # # # # # # #     log_file_handler = TimedRotatingFileHandler(filename="ds_update", when="D", interval=1, backupCount=1)
# # # # # # # #     #log_file_handler.suffix = "%Y-%m-%d_%H-%M.log"
# # # # # # # #     #log_file_handler.extMatch = re.compile(r"^\d{4}-\d{2}-\d{2}_\d{2}-\d{2}.log$")
# # # # # # # #     log_file_handler.setFormatter(formatter)
# # # # # # # #     logging.basicConfig(level=logging.INFO)
# # # # # # # #     log = logging.getLogger()
# # # # # # # #     log.addHandler(log_file_handler)
# # # # # # # #     #循环打印日志
# # # # # # # #     log_content = "test log"
# # # # # # # #     count = 0
# # # # # # # #     while count < 10:
# # # # # # # #         log.error(log_content)
# # # # # # # #         time.sleep(1)
# # # # # # # #         count = count + 1
# # # # # # # #     log.removeHandler(log_file_handler)
# # # # # # # #
# # # # # # # #
# # # # # # # # # if __name__ == "__main__":
# # # # # # # # #     backroll()
# # # # # # # # # dict={"name":"liuguiju"}
# # # # # # # # # dict["age"]=40
# # # # # # # # # dict["age"]=50
# # # # # # # # #
# # # # # # # # # print(dict["age"])
# # # # # # # # # print(5/0)
# # # # # # # # # try:
# # # # # # # # #     print(5/2)
# # # # # # # # # except Exception as e:
# # # # # # # # #     print(e)
# # # # # # # # # finally:
# # # # # # # # #     print("2323")
# # # # # # # # # print("hello world")
# # # # # # # # # print("hello world")
# # # # # # # # # print("hello world")
# # # # # # # # # import requests
# # # # # # # # # url="http://dev.usercenter.imagicdatatech.com/user/login/accountLogin"
# # # # # # # # # data="account=15811411759&password=123456"
# # # # # # # # # i=0
# # # # # # # # # while i<3:
# # # # # # # # #     res=requests.post(url=url,data=data,timeout=1)
# # # # # # # # #     i+=1
# # # # # # # # # print(res.text)
# # # # # # # # # a=2
# # # # # # # # # b=a
# # # # # # # # # a=b
# # # # # # # #
# # # # # # # # import unittest
# # # # # # # # import ddt  #第三方库
# # # # # # # #
# # # # # # # # # data=[[1,2],[3,4],[5,6]]
# # # # # # # # #
# # # # # # # # # @ddt.ddt
# # # # # # # # #
# # # # # # # # # class MyTestCase(unittest.TestCase):
# # # # # # # # #
# # # # # # # # #     # @ddt.data(*data)
# # # # # # # # #     # def test_01(self,a):
# # # # # # # # #     #     print(a)
# # # # # # # # #
# # # # # # # # #     # @ddt.data(*data)#表示可变参数取值为data([1,2],[3,4],[5,6])，若传参是data,则后面的取值 data([[1,2],[3,4],[5,6]])
# # # # # # # # #     # @ddt.unpack
# # # # # # # # #     # def test_02(self,a,b):
# # # # # # # # #     #     print(a,'----',b)
# # # # # # # # #     #
# # # # # # # # #     @ddt.data([1,2],[3,4])#和上面的相似，这里未使用变量
# # # # # # # # #     @ddt.unpack
# # # # # # # # #     def test_03(self,a,b):
# # # # # # # # #         print(a, '----', b)
# # # # # # # #
# # # # # # # # # if __name__ == '__main__':
# # # # # # # # #     unittest.main(verbosity=2)
# # # # # # # # # import os
# # # # # # # # # path="./testFile/case/"
# # # # # # # # # xls_name="userCase.xlsx"
# # # # # # # # # cls = []
# # # # # # # # # xlsPath = os.path.join(path, xls_name)
# # # # # # # # # file = open_workbook(xlsPath)  # 打开用例Excel
# # # # # # # # # sheet = file.sheet_by_name("login")  # 获得打开Excel的sheet
# # # # # # # # # # 获取这个sheet内容行数
# # # # # # # # # nrows = sheet.nrows
# # # # # # # # # for i in range(nrows):  # 根据行数做循环
# # # # # # # # #     if sheet.row_values(i)[1] != u'case_name':  # 如果这个Excel的这个sheet的第i行的第一列不等于case_name那么我们把这行的数据添加到cls[]
# # # # # # # # #         cls.append(sheet.row_values(i))
# # # # # # # # # # print(cls)
# # # # # # # # # import ddt
# # # # # # # # # import unittest
# # # # # # # # #
# # # # # # # # # @ddt.ddt
# # # # # # # # # class TestLogin(unittest.TestCase):
# # # # # # # # #     @ddt.data(*cls)
# # # # # # # # #     @ddt.unpack
# # # # # # # # #     def test(self,case_no,case_name,path,query,method,expect_result,expect_content):
# # # # # # # # #         print(self,case_no,case_name,path,query,method,expect_result,expect_content)
# # # # # # # # # # if __name__ == '__main__':
# # # # # # # # # #     unittest.main(verbosity=2)
# # # # # # # #
# # # # # # # # import  xlwt
# # # # # # # # import xlrd
# # # # # # # # data=xlrd.open_workbook("./testFile/case/userCase.xlsx")
# # # # # # # # table=data.sheet_by_name("login")
# # # # # # # # # print(table)
# # # # # # # # # nrows=table.nrows
# # # # # # # # # ncols=table.ncols
# # # # # # # # # print(nrows,ncols)
# # # # # # # # # for i in range(nrows):
# # # # # # # # #     for j in range(ncols):
# # # # # # # # #         row_content = table.col(j)[i].value  # 先行后列
# # # # # # # # #         print(row_content)
# # # # # # # # #         col_content = table.row(i)[j].value
# # # # # # # # #         print(col_content)
# # # # # # # # # content=table.cell(3,4).value
# # # # # # # # # content=table.col(1)[0].value
# # # # # # # # # content=table.row(0)[0].value
# # # # # # # # # # print(content)
# # # # # # # # # book=xlwt.Workbook(encoding="utf-8")
# # # # # # # # # sheet1=book.add_sheet("test")
# # # # # # # # # style=xlwt.XFStyle()
# # # # # # # # # sheet1.write(0,1,content)
# # # # # # # # # book.save("test.xls")
# # # # # # # # # import xlwt
# # # # # # # # # # 创建一个workbook 设置编码
# # # # # # # # # workbook = xlwt.Workbook(encoding = 'utf-8')
# # # # # # # # # file = xlrd.open_workbook("./testFile/case/userCase.xlsx")  # 打开用例Excel
# # # # # # # # # sheet = file.sheet_by_name("login")  # 获得打开Excel的sheet
# # # # # # # # # worksheet = workbook.add_sheet('My Worksheet')
# # # # # # # # # sheet.write(1,0, label = 'this is test')
# # # # # # # # # workbook.save("excel.xls")
# # # # # # # #
# # # # # # # # import xlwt
# # # # # # # # # workbook = xlwt.Workbook()
# # # # # # # # # worksheet = workbook.add_sheet('My Sheet')
# # # # # # # # # pattern = xlwt.Pattern() # Create the Pattern
# # # # # # # # # pattern.pattern = xlwt.Pattern.SOLID_PATTERN # May be: NO_PATTERN, SOLID_PATTERN, or 0x00 through 0x12
# # # # # # # # # pattern.pattern_fore_colour = 5 # May be: 8 through 63. 0 = Black, 1 = White, 2 = Red, 3 = Green, 4 = Blue, 5 = Yellow, 6 = Magenta, 7 = Cyan, 16 = Maroon, 17 = Dark Green, 18 = Dark Blue, 19 = Dark Yellow , almost brown), 20 = Dark Magenta, 21 = Teal, 22 = Light Gray, 23 = Dark Gray, the list goes on...
# # # # # # # # # style = xlwt.XFStyle() # Create the Pattern
# # # # # # # # # style.pattern = pattern # Add Pattern to Style
# # # # # # # # # worksheet.write(0, 0, 'Cell Contents', style)
# # # # # # # # # try:
# # # # # # # # #     d
# # # # # # # # # except Exception as  e:
# # # # # # # # #     print(e)
# # # # # # # # # print("hello world")
# # # # # # # #
# # # # # # # # # url="./testFile/sql/uc_project"
# # # # # # # # # f=open(url,"r")
# # # # # # # # # print(f.readlines()[0])
# # # # # # # # # class Person:
# # # # # # # # #     sum=1000
# # # # # # # # #     def __init__(sd):
# # # # # # # # #         sd.name=""
# # # # # # # # #         sd.gender=""
# # # # # # # # #         sd.age=30
# # # # # # # # #         sd.numerb=Person.sum
# # # # # # # # #         print(sd.name)
# # # # # # # # #     # @classmethod
# # # # # # # # #     # def get_number(cls):
# # # # # # # # #     #     print(sd.age)
# # # # # # # # #     def __del__(self):
# # # # # # # # #         print("execute finish!!!")
# # # # # # # # #     @staticmethod
# # # # # # # # #     def test_staticmethod():
# # # # # # # # #        print(Person.sum)
# # # # # # # #     # def __str__(self):
# # # # # # # # #     #     return self.name,self.gender,self.age
# # # # # # # #
# # # # # # # # # run=Person()
# # # # # # # # # del run
# # # # # # # # # Person.test_staticmethod()
# # # # # # # # # run.get_number()
# # # # # # # # # Person.get_number()
# # # # # # # # # print(run.numerb)
# # # # # # # # # run.name="liuguiju"
# # # # # # # # # print(run.__dict__)
# # # # # # # # # # print(run.__str__())
# # # # # # # # # def test():
# # # # # # # # #     def
# # # # # # # #
# # # # # # # # # Person.test_staticmethod()
# # # # # # # #
# # # # # # # # class Test(object):
# # # # # # # #     def __init__(self, name):
# # # # # # # #         self.name = name
# # # # # # # #         print('这是构造函数')
# # # # # # # #
# # # # # # # #     def say_hi(self):
# # # # # # # #         print('hell, %s' % self.name)
# # # # # # # #
# # # # # # # #     def __del__(self):
# # # # # # # #         print('这是1函数')
# # # # # # # #
# # # # # # # #     # def __del__(self):
# # # # # # # #     #     print('这是23332函数')
# # # # # # # #     #
# # # # # # # #     # def __del__(self):
# # # # # # # #     #     print('这是11111@@函数')
# # # # # # # # # test=Test("liuguiju")
# # # # # # # # # del test
# # # # # # # # # print(test.__dict__)
# # # # # # # # # print(test.__dict__)
# # # # # # # # # print(test.__dict__)
# # # # # # # # # print(test.__dict__)
# # # # # # # # # print(test.name)
# # # # # # # # # print(test.name)
# # # # # # # # # print(test.name)
# # # # # # # # # print(test.name)
# # # # # # # #
# # # # # # # # class ParentClass1: #定义父类
# # # # # # # #     pass
# # # # # # # #
# # # # # # # # class ParentClass2: #定义父类
# # # # # # # #     pass
# # # # # # # #
# # # # # # # # class SubClass1(ParentClass1): #单继承，基类是ParentClass1，派生类是SubClass
# # # # # # # #     pass
# # # # # # # #
# # # # # # # # class SubClass2(ParentClass1,ParentClass2): #python支持多继承，用逗号分隔开多个继承的类
# # # # # # # #     pass
# # # # # # # # # print(ParentClass1.__bases__)
# # # # # # # #
# # # # # # # # # class Animal:
# # # # # # # # #     '''
# # # # # # # # #     人和狗都是动物，所以创造一个Animal基类
# # # # # # # # #     '''
# # # # # # # # #     def __init__(self, name, aggressivity, life_value):
# # # # # # # # #         self.name = name  # 人和狗都有自己的昵称;
# # # # # # # # #         self.aggressivity = aggressivity  # 人和狗都有自己的攻击力;
# # # # # # # # #         self.life_value = life_value  # 人和狗都有自己的生命值;
# # # # # # # # #
# # # # # # # # #     def eat(self):
# # # # # # # # #         print('%s is eating'%self.name)
# # # # # # # #
# # # # # # # # # class Dog(Animal):
# # # # # # # # #     pass
# # # # # # # # #
# # # # # # # # # class Person(Animal):
# # # # # # # # #     pass
# # # # # # # #
# # # # # # # # # egg = Person('egon',10,1000)
# # # # # # # # # ha2 = Dog('二愣子',50,1000)
# # # # # # # # # egg.eat()
# # # # # # # # # ha2.eat()
# # # # # # # #
# # # # # # # # class Animal:
# # # # # # # #     def eat(self):
# # # # # # # #         print("%s 吃 " % self.name)
# # # # # # # #
# # # # # # # #     def drink(self):
# # # # # # # #         print("%s 喝 " % self.name)
# # # # # # # #
# # # # # # # #     def shit(self):
# # # # # # # #         print("%s 拉 " % self.name)
# # # # # # # #
# # # # # # # #     def pee(self):
# # # # # # # #         print("%s 撒 " % self.name)
# # # # # # # #
# # # # # # # #
# # # # # # # # class Cat(Animal):
# # # # # # # #
# # # # # # # #     def __init__(self, name):
# # # # # # # #         self.name = name
# # # # # # # #         self.breed = '猫'
# # # # # # # #
# # # # # # # #     def climb(self):
# # # # # # # #         print ('爬树')
# # # # # # # #
# # # # # # # #
# # # # # # # # class Dog(Animal):
# # # # # # # #
# # # # # # # #     def __init__(self, name):
# # # # # # # #         self.name = name
# # # # # # # #         self.breed = '狗'
# # # # # # # #
# # # # # # # #     def guard (self):
# # # # # # # #         print ('看门')
# # # # # # # #
# # # # # # # #
# # # # # # # # # c1 = Cat('小白家的小黑猫')
# # # # # # # # # c1.eat()
# # # # # # # # # c1.climb()
# # # # # # # #
# # # # # # # # # c2 = Cat('小黑的小白猫')
# # # # # # # # # c2.drink()
# # # # # # # # #
# # # # # # # # # d1 = Dog('胖子家的小瘦狗')
# # # # # # # # # d1.eat()
# # # # # # # # class D:
# # # # # # # #
# # # # # # # #     def bar(self):
# # # # # # # #         print ('D.bar')
# # # # # # # #
# # # # # # # #
# # # # # # # # class C(D):
# # # # # # # #
# # # # # # # #     def bar(self):
# # # # # # # #         print ('C.bar')
# # # # # # # #
# # # # # # # #
# # # # # # # # class B(D):
# # # # # # # #
# # # # # # # #     def bar(self):
# # # # # # # #         print ('B.bar')
# # # # # # # #
# # # # # # # #
# # # # # # # # class A(B, C):
# # # # # # # #
# # # # # # # #     def bar(self):
# # # # # # # #         print ('A.bar')
# # # # # # # #
# # # # # # # # # a = A()
# # # # # # # # # a.bar()
# # # # # # # #
# # # # # # # # #
# # # # # # # # # class Alipay:
# # # # # # # # #     '''
# # # # # # # # #     支付宝支付
# # # # # # # # #     '''
# # # # # # # # #     def pay(self,money):
# # # # # # # # #         print('支付宝支付了%s元'%money)
# # # # # # # # #
# # # # # # # # # class Applepay:
# # # # # # # # #     '''
# # # # # # # # #     apple pay支付
# # # # # # # # #     '''
# # # # # # # # #     def pay(self,money):
# # # # # # # # #         print('apple pay支付了%s元'%money)
# # # # # # # # #
# # # # # # # # #
# # # # # # # # # def pay(payment,money):
# # # # # # # # #     '''
# # # # # # # # #     支付函数，总体负责支付
# # # # # # # # #     对应支付的对象和要支付的金额
# # # # # # # # #     '''
# # # # # # # # #     payment.pay(money)
# # # # # # # #
# # # # # # # # #
# # # # # # # # # p = Alipay()
# # # # # # # # # pay(p,200)
# # # # # # # #
# # # # # # # #
# # # # # # # # # class Alipay:
# # # # # # # # #     '''
# # # # # # # # #     支付宝支付
# # # # # # # # #     '''
# # # # # # # # #     def pay(self,money):
# # # # # # # # #         print('支付宝支付了%s元'%money)
# # # # # # # # #
# # # # # # # # # class Applepay:
# # # # # # # # #     '''
# # # # # # # # #     apple pay支付
# # # # # # # # #     '''
# # # # # # # # #     def pay(self,money):
# # # # # # # # #         print('apple pay支付了%s元'%money)
# # # # # # # # #
# # # # # # # # # class Wechatpay:
# # # # # # # # #     def fuqian(self,money):
# # # # # # # # #         '''
# # # # # # # # #         实现了pay的功能，但是名字不一样
# # # # # # # # #         '''
# # # # # # # # #         print('微信支付了%s元'%money)
# # # # # # # # #
# # # # # # # # # def pay(payment,money):
# # # # # # # # #     '''
# # # # # # # # #     支付函数，总体负责支付
# # # # # # # # #     对应支付的对象和要支付的金额
# # # # # # # # #     '''
# # # # # # # # #     payment.fuqian(200)
# # # # # # # # #
# # # # # # # # #
# # # # # # # # # p = Wechatpay()
# # # # # # # # # pay(p,200)   #执行会报错
# # # # # # # #
# # # # # # # # # class Payment:
# # # # # # # # #     def pay(self):
# # # # # # # # #         raise NotImplementedError
# # # # # # # # #
# # # # # # # # # class Wechatpay(Payment):
# # # # # # # # #     def fuqian(self,money):
# # # # # # # # #         print('微信支付了%s元'%money)
# # # # # # # # #
# # # # # # # # #
# # # # # # # # # p = Wechatpay()  #这里不报错
# # # # # # # # # p.pay()
# # # # # # # #
# # # # # # # # # from abc import ABCMeta,abstractmethod
# # # # # # # # #
# # # # # # # # # class Payment(metaclass=ABCMeta):
# # # # # # # # #     @abstractmethod
# # # # # # # # #     def pay(self,money):
# # # # # # # # #         pass
# # # # # # # # #
# # # # # # # # #
# # # # # # # # # class Wechatpay(Payment):
# # # # # # # # #     def fuqian(self,money):
# # # # # # # # #         print('微信支付了%s元'%money)
# # # # # # # # #
# # # # # # # # # p = Wechatpay() #不调就报错了
# # # # # # # # # p.pay(100)
# # # # # # # #
# # # # # # # # """
# # # # # # # #     情景：手雷爆炸，可能伤害敌人或者玩家的生命。
# # # # # # # #     变化：还可能伤害房子、树、鸭子....
# # # # # # # #     要求：增加新事物，不影响手雷.
# # # # # # # #     体会：开闭原则
# # # # # # # #         增加新攻击目标,手雷不改变.
# # # # # # # #     画出架构设计图
# # # # # # # # """
# # # # # # # #
# # # # # # # #
# # # # # # # # # ----------架构师-----------
# # # # # # # # class Grenade:
# # # # # # # #     def explode(self, target):
# # # # # # # #         print("手雷爆炸")
# # # # # # # #         # 1. 编码时  调用父
# # # # # # # #         #    运行时  执行子
# # # # # # # #         target.damage()
# # # # # # # #
# # # # # # # # class AttackTarget:
# # # # # # # #     def damage(self):
# # # # # # # #         pass
# # # # # # # #
# # # # # # # # # ----------程序员-----------
# # # # # # # # class Enemy(AttackTarget):
# # # # # # # #
# # # # # # # #     # 2. 子重写
# # # # # # # #     def damage(self):
# # # # # # # #         print("敌人受伤")
# # # # # # # #
# # # # # # # # class Player(AttackTarget):
# # # # # # # #
# # # # # # # #     def damage(self):
# # # # # # # #         print("玩家受伤")
# # # # # # # #
# # # # # # # # g01 = Grenade()
# # # # # # # # e01 = Enemy()
# # # # # # # # p01 = Player()
# # # # # # # # # 3. 创建子
# # # # # # # # g01.explode(e01)
# # # # # # # #
# # # # # # # #
# # # # # # # # """
# # # # # # # #     创建图形管理器
# # # # # # # # 	1. 记录多种图形（圆形、矩形....）
# # # # # # # # 	2. 提供计算总面积的方法.
# # # # # # # #     满足：
# # # # # # # #         开闭原则
# # # # # # # #     测试：
# # # # # # # #         创建图形管理器，存储多个图形对象。
# # # # # # # #         通过图形管理器，调用计算总面积方法.
# # # # # # # #
# # # # # # # #     三大特征
# # # # # # # #         封装：创建GraphicManager、Circle、Rectanle
# # # # # # # #         继承：创建Graphic图形(抽象/统一/隔离 具体图形)
# # # # # # # #         多态:GraphicManager调用Graphic
# # # # # # # #             Circle、Rectanle重写Graphic
# # # # # # # #             向GraphicManager添加Circle、Rectanle对象
# # # # # # # #     六大原则：
# # # # # # # #         开闭：增加新图形,图形管理器不变.
# # # # # # # #         单一职责：
# # # # # # # #             GraphicManager管理所有图形
# # # # # # # #             Circle 计算圆形面积
# # # # # # # #             Rectanle 计算矩形面积
# # # # # # # #         依赖倒置：GraphicManager使用父Graphic
# # # # # # # #         组合复用：GraphicManager与图形
# # # # # # # #
# # # # # # # # """
# # # # # # # class GraphicManager:
# # # # # # #     def __init__(self):
# # # # # # #         self.all_graphic = []
# # # # # # #
# # # # # # #     # graphic 类型是父类图形
# # # # # # #     def add_graphic(self,graphic):
# # # # # # #         self.all_graphic.append(graphic)
# # # # # # #
# # # # # # #     def calculate_total_area(self):
# # # # # # #         total_area = 0
# # # # # # #         for graphic in self.all_graphic:
# # # # # # #             # 使用所有图形的统一行为
# # # # # # #             total_area += graphic.get_area()
# # # # # # #         return total_area
# # # # # # #
# # # # # # # class Graphic:
# # # # # # #     def get_area(self):
# # # # # # #         """
# # # # # # #             计算该图形面积
# # # # # # #         :return: 数值类型,图形的面积
# # # # # # #         """
# # # # # # #         pass
# # # # # # #
# # # # # # # # 父类在约束所有所有子类在某一行为上达到统一
# # # # # # # class Circle(Graphic):
# # # # # # #     def __init__(self,r):
# # # # # # #         self.r = r
# # # # # # #
# # # # # # #     def get_area(self):
# # # # # # #         # 扩展重写
# # # # # # #         # super().get_area()
# # # # # # #         return 3.14 * self.r ** 2
# # # # # # #
# # # # # # # class Rectanle(Graphic):
# # # # # # #     def __init__(self, l,w):
# # # # # # #         self.l = l
# # # # # # #         self.w = w
# # # # # # #
# # # # # # #     def get_area(self):
# # # # # # #         return self.l * self.w
# # # # # # #
# # # # # # # # manager = GraphicManager()
# # # # # # # # manager.add_graphic(Circle(5))
# # # # # # # # manager.add_graphic(Rectanle(5, 6))
# # # # # # # # print(manager.calculate_total_area())
# # # # # # # #
# # # # # # # # """
# # # # # # # #     创建员工管理器
# # # # # # # #         1. 记录多个员工（程序员、测试员....）
# # # # # # # #         2. 提供计算总薪资的方法.
# # # # # # # #
# # # # # # # #     程序员：底薪 + 项目分红
# # # # # # # #     测试员: 底薪 + Bug数 × 5
# # # # # # # #
# # # # # # # #     满足：
# # # # # # # #         开闭原则
# # # # # # # #     测试：
# # # # # # # #         创建员工管理器，存储多个员工对象。
# # # # # # # #         通过员工管理器，调用计算总薪资方法.
# # # # # # # #
# # # # # # # #     三大特征
# # # # # # # #         封装：创建EmployeeManager、Programmer、Tester
# # # # # # # #         继承：创建Employee
# # # # # # # #         多态:EmployeeManager调用Employee
# # # # # # # #             Programmer、Tester重写Employee
# # # # # # # #             向EmployeeManager添加的是Programmer、Tester对象
# # # # # # # #
# # # # # # # #     六大原则：
# # # # # # # #         开闭：增加新岗位的员工，EmployeeManager不改变
# # # # # # # #         单一职责：
# # # # # # # #             EmployeeManager操作所有员工
# # # # # # # #             Programmer负责实现程序员的薪资算法
# # # # # # # #             Tester负责实现测试员的薪资算法
# # # # # # # #         依赖倒置：
# # # # # # # #             EmployeeManager使用Employee
# # # # # # # #             不使用Programmer、Tester
# # # # # # # #         组合复用：
# # # # # # # #             EmployeeManager和员工薪资算法
# # # # # # # #         里氏替换：
# # # # # # # #             Programmer、Tester重写时先调用父类方法
# # # # # # # #         迪米特法则：
# # # # # # # #             Employee隔离EmployeeManager与Programmer、Tester的变化
# # # # # # # # """
# # # # # # # #
# # # # # # # # class EmployeeManager:
# # # # # # # #     def __init__(self):
# # # # # # # #         self.all_employee = []
# # # # # # # #
# # # # # # # #     def add_employee(self, emp):
# # # # # # # #         self.all_employee.append(emp)
# # # # # # # #
# # # # # # # #     def calculate_total_money(self):
# # # # # # # #         total_money = 0
# # # # # # # #         for emp in self.all_employee:
# # # # # # # #             total_money += emp.get_money()
# # # # # # # #         return total_money
# # # # # # # #
# # # # # # # #
# # # # # # # # class Employee:
# # # # # # # #     def get_money(self):
# # # # # # # #         pass
# # # # # # # #
# # # # # # # #
# # # # # # # # # --------------------------------
# # # # # # # #
# # # # # # # # class Programmer(Employee):
# # # # # # # #     def __init__(self, base_salary, bonus):
# # # # # # # #         self.base_salary = base_salary
# # # # # # # #         self.bonus = bonus
# # # # # # # #
# # # # # # # #     def get_money(self):
# # # # # # # #         super().get_money()
# # # # # # # #         return self.base_salary + self.bonus
# # # # # # # #
# # # # # # # #
# # # # # # # # class Tester(Employee):
# # # # # # # #     def __init__(self, base_salary, bug_count):
# # # # # # # #         self.base_salary = base_salary
# # # # # # # #         self.bug_count = bug_count
# # # # # # # #
# # # # # # # #     def get_money(self):
# # # # # # # #         super().get_money()
# # # # # # # #         return self.base_salary + self.bug_count * 5
# # # # # # # #
# # # # # # # #
# # # # # # # # # manager = EmployeeManager()
# # # # # # # # # manager.add_employee(Programmer(8000, 100000))
# # # # # # # # # manager.add_employee(Tester(5000, 500))
# # # # # # # # # print(manager.calculate_total_money())
# # # # # # # class Person:
# # # # # # #     def __init__(self,name):
# # # # # # #         self.name=name
# # # # # # #         self.__age = None
# # # # # # #
# # # # # # #         @property
# # # # # # #         def age(self):
# # # # # # #             return self.__age
# # # # # # #
# # # # # # #         @age.setter
# # # # # # #         def age(self, value):
# # # # # # #             self.__age = value
# # # # # # #     def __str__(self):
# # # # # # #         return "sds "
# # # # # # #         # self.__age=age
# # # # # # # #     @staticmethod
# # # # # # # #     def run():
# # # # # # # #         print("running")
# # # # # # # #
# # # # # # # # n1=Person("liuguiju")
# # # # # # # # n1.age=12212
# # # # # # # # n1.gender="男"
# # # # # # # # n1.age()
# # # # # # # # print(n1.__str__())
# # # # # # # # # n2=Person("liuguiju")
# # # # # # # # print(n1.__dict__)
# # # # # # # # ----------架构师-----------
# # # # # # # class Grenade:
# # # # # # #     # def explode(self, target):
# # # # # # #     #     print("手雷爆炸")
# # # # # # #     #     # 1. 编码时  调用父
# # # # # # #     #     #    运行时  执行子
# # # # # # #     #     target.damage()
# # # # # # #     def explode(self,target):
# # # # # # #         target.damage()
# # # # # # # class AttackTarget:
# # # # # # #     def damage(self):
# # # # # # #         pass
# # # # # # # # ----------程序员-----------
# # # # # # # class Enemy(AttackTarget):
# # # # # # #
# # # # # # #     # 2. 子重写
# # # # # # #     def damage(self):
# # # # # # #         print("敌人受伤")
# # # # # # #
# # # # # # # class Player(AttackTarget):
# # # # # # #
# # # # # # #     def damage(self):
# # # # # # #         print("玩家受伤")
# # # # # # # # g1=Grenade()
# # # # # # # # # a1=AttackTarget()
# # # # # # # # e1=Enemy()
# # # # # # # # g1.explode(e1)
# # # # # # #
# # # # # # #
# # # # # # # # """
# # # # # # # #     创建员工管理器
# # # # # # # #         1. 记录多个员工（程序员、测试员....）
# # # # # # # #         2. 提供计算总薪资的方法.
# # # # # # # #
# # # # # # # #     程序员：底薪 + 项目分红
# # # # # # # #     测试员: 底薪 + Bug数 × 5
# # # # # # # #
# # # # # # # #     满足：
# # # # # # # #         开闭原则
# # # # # # # #     测试：
# # # # # # # #         创建员工管理器，存储多个员工对象。
# # # # # # # #         通过员工管理器，调用计算总薪资方法.
# # # # # # # #
# # # # # # # #     三大特征
# # # # # # # #         封装：创建EmployeeManager、Programmer、Tester
# # # # # # # #         继承：创建Employee
# # # # # # # #         多态:EmployeeManager调用Employee
# # # # # # # #             Programmer、Tester重写Employee
# # # # # # # #             向EmployeeManager添加的是Programmer、Tester对象
# # # # # # # #
# # # # # # # #     六大原则：
# # # # # # # #         开闭：增加新岗位的员工，EmployeeManager不改变
# # # # # # # #         单一职责：
# # # # # # # #             EmployeeManager操作所有员工
# # # # # # # #             Programmer负责实现程序员的薪资算法
# # # # # # # #             Tester负责实现测试员的薪资算法
# # # # # # # #         依赖倒置：
# # # # # # # #             EmployeeManager使用Employee
# # # # # # # #             不使用Programmer、Tester
# # # # # # # #         组合复用：
# # # # # # # #             EmployeeManager和员工薪资算法
# # # # # # # #         里氏替换：
# # # # # # # #             Programmer、Tester重写时先调用父类方法
# # # # # # # #         迪米特法则：
# # # # # # # #             Employee隔离EmployeeManager与Programmer、Tester的变化
# # # # # # # # """
# # # # # # # #
# # # # # # # class EmployeeManager:
# # # # # # #     def __init__(self):
# # # # # # #         self.all_employee = []
# # # # # # #
# # # # # # #     def add_employee(self, emp):
# # # # # # #         self.all_employee.append(emp)
# # # # # # #
# # # # # # #     def calculate_total_money(self):
# # # # # # #         total_money = 0
# # # # # # #         for emp in self.all_employee:
# # # # # # #             total_money += emp.get_money()
# # # # # # #         return total_money
# # # # # # #
# # # # # # #
# # # # # # # class Employee:
# # # # # # #     def get_money(self):
# # # # # # #         self.number=10
# # # # # # #         self.bonus=2
# # # # # # #
# # # # # # #
# # # # # # # class Programmer(Employee):
# # # # # # #     def __init__(self, base_salary, bonus):
# # # # # # #         self.base_salary = base_salary
# # # # # # #         self.bonus = bonus
# # # # # # #
# # # # # # #     def get_money(self):
# # # # # # #         super().get_money()
# # # # # # #         print(self.bonus)
# # # # # # #         return self.base_salary + self.bonus+self.number
# # # # # # #
# # # # # # #
# # # # # # # class Tester(Employee):
# # # # # # #     def __init__(self, base_salary, bug_count):
# # # # # # #         self.base_salary = base_salary
# # # # # # #         self.bug_count = bug_count
# # # # # # #
# # # # # # #     def get_money(self):
# # # # # # #         # super().get_money()
# # # # # # #         return self.base_salary + self.bug_count * 5
# # # # # # #
# # # # # # #
# # # # # # # # manager = EmployeeManager()
# # # # # # # # manager.add_employee(Programmer(8, 10))
# # # # # # # # # manager.add_employee(Tester(5000, 500))
# # # # # # # # print(manager.calculate_total_money())
# # # # # # #
# # # # # # #
# # # # # # # class NumberManager:
# # # # # # #     def calculate(self,dept):
# # # # # # #         dept.calculate()
# # # # # # # class DepartMent:
# # # # # # #     def calculate(self):
# # # # # # #         print("合计4人")
# # # # # # # class Ceshi(DepartMent):
# # # # # # #     def calculate1(self):
# # # # # # #         print("1人")
# # # # # # # class Kaifa(DepartMent):
# # # # # # #     def calculate(self):
# # # # # # #         print("3人")
# # # # # # # # n1=NumberManager()
# # # # # # # # c1=Ceshi()
# # # # # # # # n1.calculate(c1)
# # # # # # # class D:
# # # # # # #
# # # # # # #     def bar(self):
# # # # # # #         print ('D.bar')
# # # # # # #
# # # # # # #
# # # # # # # class C(D):
# # # # # # #
# # # # # # #     def bar(self):
# # # # # # #         print ('C.bar')
# # # # # # #
# # # # # # #
# # # # # # # class B(D):
# # # # # # #
# # # # # # #     def bar1(self):
# # # # # # #         print ('B.bar')
# # # # # # #
# # # # # # #
# # # # # # # class A(B, C):
# # # # # # #
# # # # # # #     def bar1(self):
# # # # # # #         print ('A.bar')
# # # # # # # # A().bar()
# # # # # # # class Wife:
# # # # # # #     def __init__(self,age):
# # # # # # #         self.age =age # 2
# # # # # # #
# # # # # # #     @property
# # # # # # #     def age(self):
# # # # # # #         return self.__age
# # # # # # #
# # # # # # #     @age.setter
# # # # # # #     def age(self, value):  # 3
# # # # # # #         if 1 <= value <= 100:
# # # # # # #             self.__age = value
# # # # # # #         else:
# # # # # # #             raise Exception("您输入的年龄不在1至100内")
# # # # # # #
# # # # # # #
# # # # # # #
# # # # # # # w01 = Wife(12)  # 1
# # # # # # # # print(w01.name)
# # # # # # # print(w01.age)  #
# # # # # # #
# # # # # # # class Animal:
# # # # # # #     def run(self):
# # # # # # #         print('running')
# # # # # # # class Dog(Animal):
# # # # # # #     def run(self):
# # # # # # #         print("running")
# # # # # # # def run(run):
# # # # # # #     run.run()
# # # # # # # # run(Dog())
# # # # # # # #
# # # # # # # # print(__doc__)
# # # # # # # # print(__name__)
# # # # # # #
# # # # # # # def func01():
# # # # # # #     # 局部变量：对文件而言
# # # # # # #     # 外部嵌套变量：对func02而言
# # # # # # #     a = 5010
# # # # # # #
# # # # # # #     # 内部函数
# # # # # # #     def func02():
# # # # # # #         # 内部函数可以访问外部函数变量
# # # # # # #         print(a)
# # # # # # #
# # # # # # #     func02()
# # # # # # #
# # # # # # # # 调用外部函数(内部函数不执行)
# # # # # # # # func01()
# # # # # # # def func03():
# # # # # # #     a = 10
# # # # # # #
# # # # # # #     # 内部函数
# # # # # # #     def func04():
# # # # # # #         # 如果修改外部函数变量,必须通过nonlocal声明
# # # # # # #         # nonlocal a
# # # # # # #         a = 20
# # # # # # #
# # # # # # #     func04()
# # # # # # #     # print(a)# ?
# # # # # # #
# # # # # # # # func03()
# # # # # # #
# # # # # # # """
# # # # # # #     闭包 - 语法
# # # # # # #         字面意思：封闭(保存外部函数)内存空间(栈帧)
# # # # # # #         目的：内部函数,可以在外部函数执行后,访问其变量
# # # # # # #         价值：
# # # # # # # """
# # # # # # #
# # # # # # #
# # # # # # # def func01():
# # # # # # #     a = 10
# # # # # # #
# # # # # # #     def func02():
# # # # # # #         print(a) # 可以访问外部变量(因为外部函数栈帧没释放)
# # # # # # #
# # # # # # #     return func02
# # # # # # #
# # # # # # # # 调用外部函数(不执行内部函数)
# # # # # # # result=func01()
# # # # # # # # 调用内部函数
# # # # # # # # result()# 10
# # # # # # # """
# # # # # # #     闭包 - 应用
# # # # # # #         逻辑连续
# # # # # # #             外部函数调用一次,内部函数调用多次,
# # # # # # #             内部函数都可以访问外部函数变量
# # # # # # #
# # # # # # #             从一次得钱,到多次花钱的过程,可以连续不中断
# # # # # # # """
# # # # # # #
# # # # # # #
# # # # # # # def give_gife_money(money):  # 得钱
# # # # # # #     print("得到了%d元压岁钱" % money)
# # # # # # #
# # # # # # #     def child_buy(commodity, price):  # 花钱
# # # # # # #         nonlocal money
# # # # # # #         money -= price
# # # # # # #         print("购买了%s,花了%d元,还剩下%d元" % (commodity, price, money))
# # # # # # #
# # # # # # #     return child_buy
# # # # # # #
# # # # # # # # action = give_gife_money(1000)
# # # # # # # # # action1 = give_gife_money(2000)
# # # # # # # # action("变形金刚",200)
# # # # # # # # action("遥控飞机",500)
# # # # # # # # # action("糖",100)
# # # # # # # """
# # # # # # #     装饰器 - 应用
# # # # # # # """
# # # # # # # # 需求：不改变func01调用,以及内部的情况下
# # # # # # # #      为其增加新功能(打印函数名称)
# # # # # # #
# # # # # # # def print_func_name(func):  # 得到旧功能
# # # # # # #     def wrapper(*args, **kwargs):  # 新功能 + 旧功能
# # # # # # #         # 新功能：打印传入的函数名称
# # # # # # #         print("-----", func.__name__, "-----")
# # # # # # #         # 旧功能：执行传入的函数
# # # # # # #         return func(*args, **kwargs)
# # # # # # #
# # # # # # #     return wrapper
# # # # # # #
# # # # # # # def func01():
# # # # # # #     print("func01执行了")
# # # # # # # # func01=print_func_name(func01)
# # # # # # # # func01=print_func_name(func01)
# # # # # # # # func01()
# # # # # # # # func01()
# # # # # # #
# # # # # # # """
# # # # # # #     装饰器 - 细节语法
# # # # # # #         1. 内部函数返回值是旧功能返回值
# # # # # # # """
# # # # # # #
# # # # # # #
# # # # # # # def print_func_name(func):
# # # # # # #     # *合:将多个位置实参合并为一个元组
# # # # # # #     # **合:将多个关键字实参合并为一个字典
# # # # # # #     def wrapper(*args, **kwargs):  # 2
# # # # # # #         print("-----", func.__name__, "-----")
# # # # # # #         # 调用的是func01
# # # # # # #         # *拆：将一个序列拆分为多个元素
# # # # # # #         # **拆：将一个字典拆分为多个键值对
# # # # # # #         return func(*args, **kwargs)  # 3 5
# # # # # # #
# # # # # # #     return wrapper
# # # # # # #
# # # # # # #
# # # # # # # @print_func_name
# # # # # # # def func01(p1, p2):  # 4
# # # # # # #     print("func01执行,参数是:", p1, p2)
# # # # # # #     return 100
# # # # # # #
# # # # # # # # 调用内部函数wrapper
# # # # # # # # re = func01(1, p2 = 2)  # 1 6
# # # # # # # # print(re)  # 100
# # # # # # #
# # # # # # # # def get():
# # # # # # # #     print(100)
# # # # # # # # print(get())
# # # # # # #
# # # # # # # def get(a,*args,name,**kwargs):
# # # # # # #     # print(a,b,c,d)
# # # # # # #     # print(name)
# # # # # # #     pass
# # # # # # # # list=[1,2,3,4]
# # # # # # # # dict={"name":"liuguiju","age":30,"gender":"男","city":"邢台"}
# # # # # # # # get(1,2,3,23,age=30,name=23)
# # # # # # """
# # # # # # 迭代器 = 可迭代对象.__iter__()
# # # # # # while True:
# # # # # #     try:
# # # # # #         print(迭代器.__next__())
# # # # # #     except StopIteration:
# # # # # #         		break
# # # # # # """
# # # # # #
# # # # # # list=[1,2,3,4,5]
# # # # # # iter=list.__iter__()
# # # # # # # while True:
# # # # # # #     try:
# # # # # # #         print(iter.__next__())
# # # # # # #     except StopIteration:
# # # # # # #         break
# # # # # # # iter=list.__iter__()
# # # # # # # print(iter.__next__())
# # # # # # # print(iter.__next__())
# # # # # # # print(iter.__next__())
# # # # # # # # print(iter.__next__())
# # # # # # # # print(iter.__next__())
# # # # # # # # print(iter.__next__())
# # # # # #
# # # # # #
# # # # # # """
# # # # # #     迭代器
# # # # # #     让自定义对象参与for循环
# # # # # #     迭代自定义对象
# # # # # #     练习:exercise02,03
# # # # # # """
# # # # # #
# # # # # #
# # # # # # class SkillIterator:
# # # # # #     def __init__(self, data):
# # # # # #         self.data = data
# # # # # #         self.index = -1
# # # # # #
# # # # # #     def __next__(self):
# # # # # #         self.index += 1
# # # # # #         if self.index < len(self.data):
# # # # # #             return self.data[self.index]
# # # # # #         else:
# # # # # #             raise StopIteration()
# # # # # #
# # # # # #
# # # # # # class SkillManager:
# # # # # #     def __init__(self):
# # # # # #         self.__skills = []
# # # # # #
# # # # # #     def add_skill(self, skill):
# # # # # #         self.__skills.append(skill)
# # # # # #
# # # # # #     def __iter__(self):
# # # # # #         return SkillIterator(self.__skills)
# # # # # #
# # # # # #
# # # # # # manager = SkillManager()
# # # # # # manager.add_skill("降龙十八掌")
# # # # # # manager.add_skill("六脉神剑")
# # # # # # manager.add_skill("乾坤大挪移")
# # # # # # # print(manager.__iter__())
# # # # # # # print(manager.__dict__)
# # # # # #
# # # # # # # 迭代自定义对象
# # # # # # for skill in manager:
# # # # # #     print(skill)
# # # # # #
# # # # # # # iterator = manager.__iter__()
# # # # # # # # print(iter)
# # # # # # # while True:
# # # # # # #     try:
# # # # # # #         item = iterator.__next__()
# # # # # # #         print(item)  # 降龙十八掌
# # # # # # #     except StopIteration:
# # # # # # #         break
# # # # # #
# # # # #
# # # # # """
# # # # #     迭代器 --> yield
# # # # #     练习:exercise05,06
# # # # # """
# # # # # class SkillManager:
# # # # #     def __init__(self):
# # # # #         self.__skills = []
# # # # #
# # # # #     def add_skill(self, skill):
# # # # #         self.__skills.append(skill)
# # # # #
# # # # #     # def __iter__(self):
# # # # #     #     print("准备")
# # # # #     #     yield self.__skills[0]
# # # # #     #
# # # # #     #     print("准备")
# # # # #     #     yield self.__skills[1]
# # # # #     #
# # # # #     #     print("准备")
# # # # #     #     yield self.__skills[2]
# # # # #     def __iter__(self):
# # # # #         for skill in self.__skills:
# # # # #             print("准备")
# # # # #             yield skill
# # # # #
# # # # #         # yield 生成迭代器代码的大致规则:
# # # # #         # 1. 将yield之前的代码定义到__next__方法中
# # # # #         # 2. 将yield之后的数据作为__next__方法返回值
# # # # #
# # # # # manager = SkillManager()
# # # # # manager.add_skill("降龙十八掌")
# # # # # manager.add_skill("六脉神剑")
# # # # # manager.add_skill("乾坤大挪移")
# # # # #
# # # # # # 迭代自定义对象
# # # # # # for skill in manager:
# # # # # #     print(skill)
# # # # #
# # # # # # iterator = manager.__iter__()
# # # # # # while True:
# # # # # #     try:
# # # # # #         item = iterator.__next__()
# # # # # #         print(item)  # 降龙十八掌
# # # # # #     except StopIteration:
# # # # # #         break
# # # # #
# # # # # # 现象:调用__iter__方法,但是不执行
# # # # # #     调用__next__方法,执行__iter__方法
# # # # # #     执行到yield返回,当再次调用__next__方法继续执行__iter__方法
# # # # # def my_range(end):
# # # # #     start = 0
# # # # #     while start < end:
# # # # #         yield start
# # # # #         start += 1
# # # # #
# # # # # for item in my_range(5):
# # # # #     print(item)
# # # # #
# # # # # # 延迟操作/惰性操作
# # # # # # 循环一次 计算一次 返回一次
# # # # # range = my_range(5)
# # # # # iterator = range.__iter__()
# # # # # while True:
# # # # #     try:
# # # # #         item = iterator.__next__()
# # # # #         print(item)
# # # # #     except StopIteration:
# # # # #         break
# # # # s={1,2,3}
# # # # for item in s:
# # # #     print(item)
# # #
# # #
# # # """
# # #     迭代器
# # #     让自定义对象参与for循环
# # #     迭代自定义对象
# # #     练习:exercise02,03
# # # """
# # #
# # #
# # # class SkillIterator:
# # #     def __init__(self, data):
# # #         self.data = data
# # #         self.index = -1
# # #
# # #     def __next__(self):
# # #         self.index += 1
# # #         if self.index < len(self.data):
# # #             return self.data[self.index]
# # #         else:
# # #             raise StopIteration()
# # #
# # #
# # # class SkillManager:
# # #     def __init__(self):
# # #         self.__skills = []
# # #
# # #     def add_skill(self, skill):
# # #         self.__skills.append(skill)
# # #
# # #     def __iter__(self):
# # #         return SkillIterator(self.__skills)
# # #
# # #
# # # manager = SkillManager()
# # # manager.add_skill("降龙十八掌")
# # # manager.add_skill("六脉神剑")
# # # manager.add_skill("乾坤大挪移")
# # #
# # # # 迭代自定义对象
# # # # for skill in manager:
# # # #     print(skill)
# # # iterator = manager.__iter__()
# # # while True:
# # #     try:
# # #         item = iterator.__next__()
# # #         print(item)  # 降龙十八掌
# # #     except StopIteration:
# # #         break
# # #
# #
# # """
# #     迭代器 --> yield
# #     练习:exercise05,06
# # """
# # class SkillManager:
# #     def __init__(self):
# #         self.__skills = []
# #
# #     def add_skill(self, skill):
# #         self.__skills.append(skill)
# #
# #     # def __iter__(self):
# #     #     print("准备")
# #     #     yield self.__skills[0]
# #     #
# #     #     print("准备")
# #     #     yield self.__skills[1]
# #     #
# #     #     print("准备")
# #     #     yield self.__skills[2]
# # #     def __iter__(self):
# # #         for skill in self.__skills:
# # #             print("准备")
# # #             yield skill
# # #
# # #         # yield 生成迭代器代码的大致规则:
# # #         # 1. 将yield之前的代码定义到__next__方法中
# # #         # 2. 将yield之后的数据作为__next__方法返回值
# # #
# # # manager = SkillManager()
# # # manager.add_skill("降龙十八掌")
# # # manager.add_skill("六脉神剑")
# # # manager.add_skill("乾坤大挪移")
# #
# # # 迭代自定义对象
# # # for skill in manager:
# # #     print(skill)
# #
# # # iterator = manager.__iter__()
# # # while True:
# # #     try:
# # #         item = iterator.__next__()
# # #         print(item)  # 降龙十八掌
# # #     except StopIteration:
# # #         break
# #
# # # 现象:调用__iter__方法,但是不执行
# # #     调用__next__方法,执行__iter__方法
# # #     执行到yield返回,当再次调用__next__方法继续执行__iter__方法
# # import  re
# # def cal_words_total(words, tag=True):
# #     '''
# #     按条件返回一句话的字数或者切分之后的句子字符串
# #     :param words:
# #     :param tag: True 返回句子字数 FALSE 返回切分之后的字符串
# #     :return:
# #     '''
# #     regex = r"[\u2e00-\uffef<>]|[0-9]+|[a-zA-Z]+\'*[a-z]*"
# #     matches = re.findall(regex, words, re.UNICODE)
# #     print(matches)
# #     if tag:
# #         return len(matches)
# #     else:
# #         return " ".join(matches)
# # words="中国At this time, we're not planning to adjust the GA da中国te, however this may change during the course of the RC cycle.中国c"
# # res=cal_words_total(words)
# # print(res)
#
#
# """
#     函数作用域
#         - 外部嵌套作用域 语法
#          # 内部函数可以访问外部函数变量
#          # 如果修改外部函数变量,必须通过nonlocal声明
# """
# # 外部函数
# def func01():
#     # 局部变量：对文件而言
#     # 外部嵌套变量：对func02而言
#     a = 10
#
#     # 内部函数
#     def func02():
#         # 内部函数可以访问外部函数变量
#         print(a)
#
#     func02()
#
# # 调用外部函数(内部函数不执行)
# # func01()
#
#
# # 外部函数
# def func03():
#     a = 10
#
#     # 内部函数
#     def func04():
#         # 如果修改外部函数变量,必须通过nonlocal声明
#         nonlocal a
#         a = 20
#
#     func04()
#     print(a)# ?
#
# # func03()
# """
#     闭包 - 语法
#         字面意思：封闭(保存外部函数)内存空间(栈帧)
#         目的：内部函数,可以在外部函数执行后,访问其变量
#         价值：
# """
#
#
# def func01():
#     a = 10
#
#     def func02():
#         print(a) # 可以访问外部变量(因为外部函数栈帧没释放)
#
#     return func02
#
# # 调用外部函数(不执行内部函数)
# result = func01()
# # 调用内部函数
# result()# 10
#
"""
    闭包 - 语法
        字面意思：封闭(保存外部函数)内存空间(栈帧)
        目的：内部函数,可以在外部函数执行后,访问其变量
        价值：
"""


# def func01():
#     a = 10
#
#     def func02():
#         print(a) # 可以访问外部变量(因为外部函数栈帧没释放)
#
#     return func02
#
# # 调用外部函数(不执行内部函数)
# result = func01()
# # 调用内部函数
# result()# 10


"""
    闭包 - 应用
        逻辑连续
            外部函数调用一次,内部函数调用多次,
            内部函数都可以访问外部函数变量

            从一次得钱,到多次花钱的过程,可以连续不中断
"""


# def give_gife_money(money):  # 得钱
#     print("得到了%d元压岁钱" % money)
#
#     def child_buy(commodity, price):  # 花钱
#         nonlocal money
#         money -= price
#         print("购买了%s,花了%d元,还剩下%d元" % (commodity, price, money))
#     child_buy(100,100)
#     # return child_buy
#
# action = give_gife_money(1000)
# action("变形金刚",200)
# action("遥控飞机",500)
# action("糖",100)


"""
    装饰器 - 应用
"""
# 需求：不改变func01调用,以及内部的情况下
#      为其增加新功能(打印函数名称)

def print_func_name(func):  # 得到旧功能
    def wrapper():  # 新功能 + 旧功能
        # 新功能：打印传入的函数名称
        print("-----", func.__name__, "-----")
        # 旧功能：执行传入的函数
        return func()

    return wrapper


# @print_func_name # 调用外部函数  绑定下面函数
@print_func_name
def func01():
    print("func01执行了")
# func01()
# func01=print_func_name(func01)
# 调用外部函数(得到了1000元)
# func01 = print_func_name(func01)
#
# # 调用内部函数(花钱)
# func01()
# func01()


"""
    装饰器 - 细节语法
        1. 内部函数返回值是旧功能返回值
"""


# def print_func_name(func):
#     # *合:将多个位置实参合并为一个元组
#     # **合:将多个关键字实参合并为一个字典
#     def wrapper(*args, **kwargs):  # 2
#         print("-----", func.__name__, "-----")
#         # 调用的是func01
#         # *拆：将一个序列拆分为多个元素
#         # **拆：将一个字典拆分为多个键值对
#         return func(*args, **kwargs)  # 3 5
#
#     return wrapper
#
#
# @print_func_name
# def func01(p1, p2):  # 4
#     print("func01执行,参数是:", p1, p2)
#     return 100
#
#
# # 调用内部函数wrapper
# re = func01(1, p2 = 2)  # 1 6
# print(re)  # 100

# import os, time
# from appium import webdriver
# PATH = lambda p:os.path.abspath(os.path.join(os.path.dirname(__file__),p))
# desired_caps = {}
# desired_caps['platformName'] = 'Android' # 设备系统
# desired_caps['platformVersion'] = '10' # 设备系统版本
# desired_caps['deviceName'] = 'SEA_AL00' # 设备名称
# desired_caps['app'] = PATH(r"D:\packet\magic_2.8.3.apk")
# desired_caps['appPackage'] = 'com.magicdata'
# desired_caps['appActivity'] = 'com.magicdata.activity.login.WelcomeActivity'
# desired_caps['automationName']='uiautomator2'
# driver = webdriver.Remote("http://localhost:4723/wd/hub", desired_caps)
# time.sleep(5)


"""
    迭代 iter:每一次对过程的重复称为一次“迭代”，
             而每一次迭代得到的结果会作为下一次迭代的初始值。
        可迭代iterable:能够完成迭代过程的对象.
        迭代器iterator:实施迭代过程的对象
    练习:exercise01
"""
message = "我是齐天大圣孙悟空"
# for item in message:
#     print(item)

# 获取迭代器对象
iterator=message.__iter__()
# iterator1=iter(message)
# print(iterator,iterator1)
while True:
    try:
        # print(iterator.__next__())
        iterator.__next__()
    except StopIteration as e:
        print(e)
        break
# print(iterator.__next__())
# for 循环原理
# 1. 获取迭代器对象

# iterator = message.__iter__()
# print(iterator.__next__())
# print(iterator.__next__())
# print(iterator.__next__())
# while True:
#     try:
#         # 2. 获取下一个元素
#         item = iterator.__next__()
#         print(item)
#         # 3. 如果没有元素,则停止循环.
#     except StopIteration:
#         break

# 面试题:可以参与for循环的条件是?
# 能够获取迭代器对象(可迭代对象)
# 具有__iter__函数

"""
    迭代器
    让自定义对象参与for循环
    迭代自定义对象
    练习:exercise02,03
"""


class SkillIterator:
    def __init__(self, data):
        self.data = data
        self.index = -1

    def __next__(self):
        self.index += 1
        if self.index < len(self.data):
            return self.data[self.index]
        else:
            raise StopIteration()


class SkillManager:
    def __init__(self):
        self.__skills = []

    def add_skill(self, skill):
        self.__skills.append(skill)

    def __iter__(self):
        return SkillIterator(self.__skills)


manager = SkillManager()
manager.add_skill("降龙十八掌")
manager.add_skill("六脉神剑")
manager.add_skill("乾坤大挪移")
# print(manager.__dict__)
# iterator=manager.__iter__()
# print(iterator.__next__())
# print(iterator.__next__())

# 迭代自定义对象
# for skill in manager:
#     print(skill)

# iterator = manager.__iter__()
# while True:
#     try:
#         item = iterator.__next__()
#         # print(item)  # 降龙十八掌
#     except StopIteration:
#         break

# list=[i*i for i in range(10)]
# list=(i*i for i in range(10))
# print(list.__next__())
# print(list.__next__())
# print(list.__next__())
# print(list.__next__())
# for item in list:
#     print(item)
# def generate(a):
#     for item in range(a):
#         yield item
# res=generate(5)
# print(res.__next__())
# print(res.__next__())

def test():
    i=0
    while i<5:
        temp=yield  i
        print(temp)
        i +=1
a=test()
# print(a.__next__())
# print(a.__next__())
# print(a.__next__())
# #
#

def count_down(n):
    while n >= 0:
        newn = yield n
        print('newn', newn)
        if newn:
            print('if')
            n = newn
            print('n =', n)
        else:
            n -= 1

#
# cd = count_down(5)
# for i in cd:
#     print(i, ',')
#     if i == 5:
#         cd.send(3)
# for i in range(10):
#     print(i*i)
list=(i*i for i in range(10))
# print(list)
def test01():
    for i in range(5):
        yield  i
# print(test01().__next__())
# print(test01().__next__())
# print(test01().__next__())
# print(test01().__next__())
# print(test01().__next__())
# for item in test01():
#     print(item)


"""
    yield --> 生成器
    MyRange3.0
    类 --> 函数
    练习:exercise08/09
"""
"""
class Generator:# 生成器 = 可迭代对象 + 迭代器
    def __iter__(self): # 可迭代对象
        return self

    def __next__(self): # 迭代器
        ....
"""


def my_range(end):
    start = 0
    while start < end:
        yield start
        start += 1


# for item in my_range(5):
#     print(item)

# 延迟操作/惰性操作
# 循环一次 计算一次 返回一次
# range = my_range(5)
# iterator = range.__iter__()
# while True:
#     try:
#         item = iterator.__next__()
#         print(item)
#     except StopIteration:
#         break


"""
    迭代器 --> yield
    练习:exercise05,06
"""
class SkillManager:
    def __init__(self):
        self.__skills = []

    def add_skill(self, skill):
        self.__skills.append(skill)
    def __iter__(self):
        for skill in self.__skills:
            print("准备")
            yield skill

        # yield 生成迭代器代码的大致规则:
        # 1. 将yield之前的代码定义到__next__方法中
        # 2. 将yield之后的数据作为__next__方法返回值

manager = SkillManager()
manager.add_skill("降龙十八掌")
manager.add_skill("六脉神剑")
manager.add_skill("乾坤大挪移")

# 迭代自定义对象
# for skill in manager:
#     print(skill)

# iterator = manager.__iter__()
# while True:
#     try:
#         item = iterator.__next__()
#         print(item)  # 降龙十八掌
#     except StopIteration:
#         break

# 现象:调用__iter__方法,但是不执行
#     调用__next__方法,执行__iter__方法
#     执行到yield返回,当再次调用__next__方法继续执行__iter__方法


# def foo():
#     print("starting...")
#     # yield 4
#     while True:
#         return 4
#     #     res = yield 4
#     #     print("res:",res)
# g = foo()
# print(g)
# print(g.__next__())
# print(next(g))
# print("*"*20)
# print(next(g))



# def foo():
#     print("starting...")
#     while True:
#         res = yield 4
#         print("res:",res)
# g = foo()
# print(g.__next__())
# print("*"*20)
# print(next(g))
# print("*"*20)
# print(next(g))

# def foo():
#     print("starting...")
#     while True:
#         res = yield 4
#         print("res:",res)
# g = foo()
# # print(next(g))
# # print("*"*20)
# # print(g.send(7))
# print(range)

# def foo():
#     print("starting...")
#     while True:
#         res = yield 4
#         print("res:",res)
# g = foo()
# # print(g)
# print(next(g))
# # print(g.__next__())
# print("*"*20)
# print(next(g))

# def foo():
#     print("starting...")
#     while True:
#         res = yield 4
#         print("res:",res)
# g = foo()
# print(next(g))
# print("*"*20)
# print(g.send(7))
#
# g=range(1000)
# for i in  g:
#     print(i)
g=[i for i in range(1000)]
print(g)



































































































































































































































































































